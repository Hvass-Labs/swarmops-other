// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Compute the standard Meta-Fitness measure, that is, perform a number of
 * optimization runs on different problems and sum their results.
 * 
 * Preemptive Fitness Evaluation is used in that optimizations will be attempted
 * aborted once the meta-fitness becomes worse than the Preemptive Fitness Limit
 * (aka. fitnessLimit). In addition, the array of problems are being sorted at
 * the end of each meta-fitness computation, so as to allow the worst performing
 * problems to be optimized first in the next meta-fitness computation, so as to
 * decrease the computation time further still.
 */
public class MetaFitness extends Problem {
	/**
	 * Construct the object, un-weighted problems.
	 * 
	 * @param optimizer
	 *            optimizer to be used.
	 * @param problems
	 *            array of problems to be optimized.
	 * @param numRuns
	 *            number of optimization runs per problem.
	 * @param maxIterations
	 *            max number of optimization iterations.
	 */
	public MetaFitness(Optimizer optimizer, Problem[] problems, int numRuns,
			int maxIterations) {
		super(maxIterations);

		this.optimizer = optimizer;
		this.numRuns = numRuns;

		problemIndex = new ProblemIndex(problems);
	}

	/**
	 * Construct the object, weighted problems.
	 * 
	 * @param optimizer
	 *            optimizer to be used.
	 * @param problems
	 *            array of weighted problems to be optimized.
	 * @param numRuns
	 *            number of optimization runs per problem.
	 * @param maxIterations
	 *            max number of optimization iterations.
	 */
	public MetaFitness(Optimizer optimizer, WeightedProblem[] weightedProblems,
			int numRuns, int maxIterations) {
		super(maxIterations);

		this.optimizer = optimizer;
		this.numRuns = numRuns;

		problemIndex = new ProblemIndex(weightedProblems);
	}

	/**
	 * Sorted index of optimization problems.
	 */
	protected ProblemIndex problemIndex;

	/**
	 * Number of optimization runs to be performed for each problem.
	 */
	public final int numRuns;

	/**
	 * Optimizer to use in optimizations.
	 */
	public final Optimizer optimizer;

	@Override
	public String getName() {
		return "MetaFitness (" + optimizer.getName() + ")";
	}

	@Override
	public double[] getLowerBound() {
		return optimizer.getLowerBound();
	}

	@Override
	public double[] getUpperBound() {
		return optimizer.getUpperBound();
	}

	@Override
	public double[] getLowerInit() {
		return optimizer.getLowerInit();
	}

	public double[] getUpperInit() {
		return optimizer.getUpperInit();
	}

	public int getDimensionality() {
		return optimizer.getDimensionality();
	}

	@Override
	public double getMinFitness() {
		// Return Zero which is the minimum fitness possible for a
		// meta-fitness measure.
		return 0;
	}

	@Override
	public String[] getParameterName() {
		return optimizer.getParameterName();
	}

	@Override
	public double fitness(double[] parameters, double fitnessLimit) {
		// / Compute the meta-fitness measure by passing the
		// / given parameters to the Optimizer, and perform
		// / optimization runs on the array of problems
		// / until the fitness compute exceeds the fitnessLimit.

		// Initialize the fitness-sum.
		double fitnessSum = 0;

		// Iterate over the problems.
		for (int i = 0; i < problemIndex.size() && fitnessSum < fitnessLimit; i++) {
			// Assign the problem to the optimizer.
			optimizer.problem = problemIndex.getProblem(i);

			// Get the weight associated with this problem.
			double weight = problemIndex.getWeight(i);

			// Use another fitness summation because we need to keep
			// track of the performance on each problem.
			double fitnessSumInner = 0;

			// Perform a number of optimization runs.
			for (int j = 0; j < numRuns && fitnessSum < fitnessLimit; j++) {
				// Perform one optimization run on the problem.
				Result result = optimizer.optimize(parameters, fitnessLimit
						- fitnessSum);

				// Get the best fitness result from optimization and adjust it
				// by subtracting its minimum possible value.
				double fitness = result.fitness;
				double fitnessAdjusted = fitness - optimizer.getMinFitness();

				// Ensure adjusted fitness is non-negative, otherwise Preemptive
				// Fitness Evaluation does not work.
				assert fitnessAdjusted >= 0;

				// Apply weight to the adjusted fitness.
				fitnessAdjusted *= weight;

				// Accumulate both fitness sums.
				fitnessSumInner += fitnessAdjusted;
				fitnessSum += fitnessAdjusted;
			}

			// Set the fitness result achieved on the problem.
			// This was why we needed an extra summation variable.
			problemIndex.setFitness(i, fitnessSumInner);
		}

		// Sort the optimization problems so that the worst
		// performing will be attempted optimized first, when
		// this method is called again.
		problemIndex.sort();

		return fitnessSum;
	}

	@Override
	public boolean enforceConstraints(double[] parameters) {
		return optimizer.enforceConstraints(parameters);
	}

	@Override
	public boolean isFeasible(double[] parameters) {
		return optimizer.isFeasible(parameters);
	}

	@Override
	public void beginOptimizationRun() {
		// At beginning of new meta-optimization run print a newline.
		Tools.printNewline();
	}
}
