// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

import java.util.Collections;
import java.util.ArrayList;

/**
 * Used for sorting optimization problems so that those hardest to optimize are
 * tried first. This is used in the MetaFitness class where Pre-emptive Fitness
 * Evaluation seeks to abort the meta-fitness evaluation as early as possible.
 */
public class ProblemIndex {
	/**
	 * Associate an optimization problem with a fitness.
	 */
	class ProblemFitness implements Comparable<ProblemFitness> {
		public ProblemFitness(Problem problem, double weight) {
			this.problem = problem;
			this.weight = weight;
			this.fitness = problem.getMaxFitness();
		}

		/**
		 * The optimization problem.
		 */
		public final Problem problem;

		/**
		 * Weight of the optimization problem.
		 */
		public final double weight;

		/**
		 * The fitness achieved when last optimizing that problem.
		 */
		public double fitness;

		@Override
		public int compareTo(ProblemFitness o) {
			assert o != null;
			
			// Return the negative to sort in descending order.
			return -(new Double(this.fitness).compareTo(o.fitness));
		}
	}

	/**
	 * Construct the ProblemIndex-object.
	 * 
	 * @param problems
	 *            the problems to be indexed with uniform weighting.
	 */
	public ProblemIndex(Problem[] problems) {
		super();

		int numProblems = problems.length;

		assert numProblems > 0;

		double weight = 1.0 / numProblems;

		index = new ArrayList<ProblemFitness>(numProblems);

		for (int i = 0; i < numProblems; i++) {
			index.add(new ProblemFitness(problems[i], weight));
		}
	}

	/**
	 * Construct the ProblemIndex-object.
	 * 
	 * @param weighted
	 *            problems the problems to be indexed.
	 */
	public ProblemIndex(WeightedProblem[] weightedProblems) {
		super();

		int numProblems = weightedProblems.length;

		// Ensure array has elements.
		assert numProblems > 0;

		index = new ArrayList<ProblemFitness>(numProblems);

		double weightSum = 0;
		for (int i = 0; i < numProblems; i++) {
			weightSum += weightedProblems[i].weight;
		}

		for (int i = 0; i < numProblems; i++) {
			WeightedProblem weightedProblem = weightedProblems[i];

			Problem problem = weightedProblem.problem;
			double weight = weightedProblem.weight;
			double weightNormalized = weight / weightSum;

			// Ensure weight is positive.
			assert weight > 0;

			index.add(new ProblemFitness(problem, weightNormalized));
		}
	}

	/**
	 * The list of optimization problems sorted according to fitness.
	 */
	ArrayList<ProblemFitness> index;

	/**
	 * Return the number of problems.
	 */
	public int size() {
		return index.size();
	}

	/**
	 * Return the i'th optimization problem, sorted so that the problems with
	 * the worst fitness have lowest indices.
	 */
	public Problem getProblem(int i) {
		return index.get(i).problem;
	}

	/**
	 * Return the weight associated with the i'th problem.
	 */
	public double getWeight(int i) {
		return index.get(i).weight;
	}

	/**
	 * Set the fitness associated with the i'th problem.
	 */
	public void setFitness(int i, double fitness) {
		index.get(i).fitness = fitness;
	}

	/**
	 * Sort the optimization problems according to their associated fitness.
	 */
	public void sort() {
		Collections.sort(index);
	}
}
