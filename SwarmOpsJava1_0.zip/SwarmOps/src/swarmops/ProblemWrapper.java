// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Transparently wrap a Problem-object by calling through for all methods.
 */
public abstract class ProblemWrapper extends Problem {
	/**
	 * Construct the object.
	 * 
	 * @param problem
	 *            problem being wrapped.
	 */
	public ProblemWrapper(Problem problem) {
		super();
		this.problem = problem;
	}

	/**
	 * The problem that is being wrapped.
	 */
	public Problem problem;

	@Override
	public String getName() {
		return problem.getName();
	}

	@Override
	public double[] getLowerBound() {
		return problem.getLowerBound();
	}

	@Override
	public double[] getUpperBound() {
		return problem.getUpperBound();
	}

	@Override
	public double[] getLowerInit() {
		return problem.getLowerInit();
	}

	@Override
	public double[] getUpperInit() {
		return problem.getUpperInit();
	}

	@Override
	public int getDimensionality() {
		return problem.getDimensionality();
	}

	@Override
	public double getMinFitness() {
		return problem.getMinFitness();
	}

	@Override
	public double getMaxFitness() {
		return problem.getMaxFitness();
	}

	@Override
	public double getAcceptableFitness() {
		return problem.getAcceptableFitness();
	}

	@Override
	public String[] getParameterName() {
		return problem.getParameterName();
	}

	@Override
	public boolean hasGradient() {
		return problem.hasGradient();
	}

	@Override
	public int gradient(double[] x, double[] v) {
		return problem.gradient(x, v);
	}

	@Override
	public boolean enforceConstraints(double[] parameters) {
		return problem.enforceConstraints(parameters);
	}

	@Override
	public boolean isFeasible(double[] parameters) {
		return problem.isFeasible(parameters);
	}

	@Override
	public void beginOptimizationRun() {
		problem.beginOptimizationRun();
	}

	@Override
	public void endOptimizationRun() {
		problem.endOptimizationRun();
	}

	@Override
	public boolean continueOptimization(int iterations, double fitness,
			boolean feasible) {
		return problem.continueOptimization(iterations, fitness, feasible);
	}
}
