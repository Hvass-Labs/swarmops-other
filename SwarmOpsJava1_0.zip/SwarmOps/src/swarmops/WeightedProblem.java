// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Problem and weight pair for use in meta-optimization.
 */
public class WeightedProblem {
	/**
	 * Construct the object, weight will be set to 1.0
	 */
	public WeightedProblem(Problem problem) {
		this(1.0, problem);
	}

	/**
	 * Construct the object.
	 */
	public WeightedProblem(double weight, Problem problem) {
		this.weight = weight;
		this.problem = problem;
	}

	/**
	 * Problem object.
	 */
	public final Problem problem;

	/**
	 * Weight
	 */
	public final double weight;
}
