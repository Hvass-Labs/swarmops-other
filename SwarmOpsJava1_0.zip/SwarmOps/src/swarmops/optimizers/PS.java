// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.optimizers;

import swarmops.Globals;
import swarmops.Optimizer;
import swarmops.Problem;
import swarmops.Result;
import swarmops.Tools;

/**
 * Pattern Search (PS), an early variant was originally due to Fermi and
 * Metropolis at the Los Alamos nuclear laboratory, as described by Davidon (1).
 * It is also sometimes called compass search. This is a slightly different
 * variant by Pedersen (2). It works for a wide variety of optimization
 * problems, especially when only few iterations are allowed. It does, however,
 * stagnate rather quickly.
 * 
 * References:
 * 
 * (1) W.C. Davidon. Variable metric method for minimization. SIAM Journal on
 * Optimization, 1(1):1-17, 1991
 * 
 * (2) M.E.H. Pedersen. Tuning & Simplifying Heuristical Optimization. PhD
 * Thesis, University of Southampton, 2010.
 */
public class PS extends Optimizer {
	/**
	 * Construct the object.
	 */
	public PS() {
		super();
	}

	/**
	 * Construct the object.
	 * 
	 * @param problem
	 *            problem to optimize.
	 */
	public PS(Problem problem) {
		super(problem);
	}

	@Override
	public double[] getDefaultParameters() {
		return null;
	}

	@Override
	public String getName() {
		return "PS";
	}

	@Override
	public double[] getLowerBound() {
		return null;
	}

	@Override
	public double[] getUpperBound() {
		return null;
	}

	@Override
	public int getDimensionality() {
		return 0;
	}

	@Override
	public Result optimize(double[] parameters) {
		// Signal beginning of optimization run.
		problem.beginOptimizationRun();

		// Get problem-context.
		double[] lowerBound = problem.getLowerBound();
		double[] upperBound = problem.getUpperBound();
		double[] lowerInit = problem.getLowerInit();
		double[] upperInit = problem.getUpperInit();
		int n = problem.getDimensionality();

		// Allocate agent position and search-range vectors.
		double[] x = new double[n]; // Current position.
		double[] y = new double[n]; // Potentially new position.
		double[] d = new double[n]; // Search-range.

		// Initialize agent-position in search-space.
		Tools.initializeUniform(x, lowerInit, upperInit);

		// Initialize search-range to full search-space.
		Tools.initializeRange(d, lowerBound, upperBound);

		// Enforce constraints and evaluate feasibility.
		boolean feasible = problem.enforceConstraints(x);

		// Compute fitness of initial position.
		// This counts as an iteration below.
		double fitness = problem.fitness(x, feasible);

		// Trace fitness of best found solution.
		trace(0, fitness, feasible);

		int i;
		for (i = 1; problem.continueOptimization(i, fitness, feasible); i++) {
			// Pick random dimension.
			int R = Globals.random.nextIndex(n);

			// Copy current position to new position
			Tools.copy(x, y);

			// Compute new value for randomly chosen dimension.
			y[R] += d[R];

			// Enforce constraints and evaluate feasibility.
			boolean newFeasible = problem.enforceConstraints(y);

			// Compute fitness if feasibility (constraint satisfaction) is same
			// or better.
			if (Tools.isBetterFeasible(feasible, newFeasible)) {
				// Compute fitness of new position.
				double newFitness = problem.fitness(y, fitness, feasible,
						newFeasible);

				// Update best known position, if improvement.
				if (Tools.isBetterFeasibleFitness(feasible, newFeasible,
						fitness, newFitness)) {
					// Update fitness.
					fitness = newFitness;

					// Update feasibility.
					feasible = newFeasible;

					// Update position by swapping array x and y.
					// This is necessary because the constraint-handler
					// may alter the position y to something different
					// from what PS computed it to be. Otherwise we
					// could just have updated the R'th dimension of x.
					double[] temp = x;
					x = y;
					y = temp;
				} else // Worse fitness.
				{
					// Reduce and invert search-range.
					d[R] *= -0.5;
				}
			} else // Worse feasibility.
			{
				// Reduce and invert search-range.
				d[R] *= -0.5;
			}

			// Trace fitness of best found solution.
			trace(i, fitness, feasible);
		}

		// Signal end of optimization run.
		problem.endOptimizationRun();

		// Return best-found solution and fitness.
		return new Result(x, fitness, feasible, i);
	}
}
