// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.optimizers;

import swarmops.Globals;
import swarmops.Optimizer;
import swarmops.Problem;
import swarmops.Result;
import swarmops.Tools;
import swarmops.random.RandomSet;

/**
 * Differential Evolution (DE) optimizer originally due to Storner and Price
 * (1). This suite offers combinations of DE variants and various perturbation
 * schemes for its behavioural parameters. Note that this has complicated the
 * implementation somewhat.
 * 
 * References:
 * 
 * (1) R. Storn and K. Price. Differential evolution - a simple and efficient
 * heuristic for global optimization over continuous spaces. Journal of Global
 * Optimization, 11:341-359, 1997.
 */
public class DESuite extends Optimizer {
	/**
	 * Construct the object.
	 */
	public DESuite(DECrossover.Variant crossover, DitherVariant dither) {
		super();
		setVariant(crossover, dither);
	}

	/**
	 * Construct the object.
	 * 
	 * @param problem
	 *            problem to optimize.
	 */
	public DESuite(Problem problem, DECrossover.Variant crossover,
			DitherVariant dither) {
		super(problem);
		setVariant(crossover, dither);
	}

	/**
	 * Enumerate the variants of dithering for the differential weight.
	 */
	public enum DitherVariant {
		/**
		 * No dither.
		 */
		None,

		/**
		 * Use same dithering for entire generation.
		 */
		Generation,

		/**
		 * Use same dithering for entire vector. (Aka. Dither.)
		 */
		Vector,

		/**
		 * Use new dithering for each element of vector. (Aka. Jitter.)
		 */
		Element
	}

	/**
	 * Set DE operator variants to be used, and determine the number of
	 * behavioural parameters associated with that variant.
	 * 
	 * @param crossover
	 *            crossover variant to be used.
	 * @param dither
	 *            dither variant to be used.
	 */
	void setVariant(DECrossover.Variant crossover, DitherVariant dither) {
		this.dither = dither;
		this.crossover = crossover;

		if (dither == DitherVariant.None) {
			this.dimensionality = 3;
		} else {
			this.dimensionality = 4;
		}
	}

	/**
	 * Return name of dither variant.
	 */
	protected String getDitherName() {
		String s;

		switch (dither) {
		case None:
			s = "";
			break;

		case Generation:
			s = "-GenDither";
			break;

		case Vector:
			s = "-VecDither";
			break;

		case Element:
			s = "-Jitter";
			break;

		default:
			s = "-UnknownDither";
			break;
		}

		return s;
	}

	private DECrossover.Variant crossover;
	private DitherVariant dither;
	private int dimensionality;

	/** Names of the control parameters. */
	private static final String[] parameterName = { "NP", "CR", "F" };

	/** Names of the control parameters. (dither) */
	private static final String[] parameterNameDither = { "NP", "CR", "FMid",
			"FRange" };

	private static final double[] defaultParameters = { 37.0, 0.496, 0.5313 };
	private static final double[] defaultParametersDither = { 9.0, 0.5749,
			1.1862, 2.1832 };

	/** Lower boundary for the control parameters. */
	private static final double[] lowerBound = { 4, 0, 0 };

	/** Lower boundary for the control parameters. (dither) */
	private static final double[] lowerBoundDither = { 4, 0, 0, 0 };

	/** Upper boundary for the control parameters. */
	private static final double[] upperBound = { 200, 1, 2.0 };

	/** Upper boundary for the control parameters. (dither) */
	private static final double[] upperBoundDither = { 200, 1, 2.0, 3.0 };

	@Override
	public double[] getDefaultParameters() {
		return (dither == DitherVariant.None) ? (defaultParameters)
				: (defaultParametersDither);
	}

	@Override
	public String getName() {
		return "DE-" + DECrossover.getName(crossover) + getDitherName();
	}

	@Override
	public String[] getParameterName() {
		return (dither == DitherVariant.None) ? (parameterName)
				: (parameterNameDither);
	}

	@Override
	public double[] getLowerBound() {
		return (dither == DitherVariant.None) ? (lowerBound)
				: (lowerBoundDither);
	}

	@Override
	public double[] getUpperBound() {
		return (dither == DitherVariant.None) ? (upperBound)
				: (upperBoundDither);
	}

	@Override
	public int getDimensionality() {
		return dimensionality;
	}

	/**
	 * Get control parameter, number of agents aka. swarm-size.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public static int getNumAgents(double[] parameters) {
		return (int) Math.round(parameters[0]);
	}

	/**
	 * Get control parameter CR aka. crossover probability.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public double getCR(double[] parameters) {
		return parameters[1];
	}

	/**
	 * Get control parameter F aka. differential weight.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public double getF(double[] parameters) {
		return (dither == DitherVariant.None) ? (parameters[2]) : (0);
	}

	/**
	 * Get control parameter FMid aka. differential weight dithering midpoint.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public double getFMid(double[] parameters) {
		return (dither != DitherVariant.None) ? (parameters[2]) : (0);
	}

	/**
	 * Get control parameter FRange aka. differential weight dithering range.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public double getFRange(double[] parameters) {
		return (dither != DitherVariant.None) ? (parameters[3]) : (0);
	}

	@Override
	public Result optimize(double[] parameters) {
		assert parameters != null && parameters.length == getDimensionality();

		// Signal beginning of optimization run.
		problem.beginOptimizationRun();

		// Retrieve parameters specific to DE method.
		int numAgents = getNumAgents(parameters);
		double CR = getCR(parameters);
		double F = getF(parameters);
		double FMid = getFMid(parameters);
		double FRange = getFRange(parameters);

		assert numAgents >= 1;

		// Get problem-context.
		double[] lowerInit = problem.getLowerInit();
		double[] upperInit = problem.getUpperInit();
		int n = problem.getDimensionality();

		// Allocate agent positions and associated fitnesses and feasibility.
		double[][] agents = new double[numAgents][n];
		double[] fitness = new double[numAgents];
		boolean[] feasible = new boolean[numAgents];
		double[] y = new double[n];

		// Allocate differential weight vector.
		double[] w = new double[n];

		// Initialize differential weight vector, if no dithering is wanted.
		if (dither == DitherVariant.None) {
			// Initialize crossover-weight vector.
			// Same value for all elements, vectors, and generations.
			Tools.initialize(w, F);
		}

		// Random set for picking distinct agents.
		RandomSet randomSet = new RandomSet(Globals.random, numAgents);

		// Iteration variables.
		int i, j;

		// Fitness variables.
		double[] g = null;
		double gFitness = problem.getMaxFitness();
		boolean gFeasible = false;

		// Initialize all agents.
		// This counts as iterations below.
		for (j = 0; j < numAgents
				&& problem.continueOptimization(j, gFitness, gFeasible); j++) {
			// Refer to the j'th agent as x.
			double[] x = agents[j];

			// Initialize agent-position in search-space.
			Tools.initializeUniform(x, lowerInit, upperInit);

			// Enforce constraints and evaluate feasibility.
			feasible[j] = problem.enforceConstraints(x);

			// Compute fitness of initial position.
			fitness[j] = problem.fitness(x, feasible[j]);

			// Update population's best known position if it either does not
			// exist or,
			// if feasibility is same or better and fitness is an improvement.
			if (Tools.isBetterFeasibleFitness(gFeasible, feasible[j], gFitness,
					fitness[j])) {
				g = agents[j];
				gFitness = fitness[j];
				gFeasible = feasible[j];
			}

			// Trace fitness of best found solution.
			trace(j, gFitness, gFeasible);
		}

		for (i = numAgents; problem
				.continueOptimization(i, gFitness, gFeasible);) {
			// Perform dithering of differential weight, depending on dither
			// variant wanted.
			if (dither == DitherVariant.Generation) {
				// Initialize differential-weight vector. Generation-based.
				Tools.initialize(w, Globals.random.nextUniform(FMid - FRange,
						FMid + FRange));
			}

			for (j = 0; j < numAgents
					&& problem.continueOptimization(i, gFitness, gFeasible); j++, i++) {
				// Perform dithering of differential weight, depending on dither
				// variant wanted.
				if (dither == DitherVariant.Vector) {
					// Initialize differential-weight vector. Vector-based.
					Tools.initialize(
							w,
							Globals.random.nextUniform(FMid - FRange, FMid
									+ FRange));
				} else if (dither == DitherVariant.Element) {
					// Initialize differential-weight vector. Element-based.
					Tools.initializeUniform(w, FMid - FRange, FMid + FRange);
				}

				// Reset the random-set used for picking distinct agents.
				// Exclude the j'th agent (also referred to as x).
				randomSet.resetExclude(j);

				// Refer to the j'th agent as x.
				double[] x = agents[j];

				// Perform crossover.
				DECrossover.crossover(crossover, CR, n, w, x, y, g, agents,
						randomSet);

				// Enforce constraints and evaluate feasibility.
				boolean newFeasible = problem.enforceConstraints(y);

				// Compute fitness if feasibility (constraint satisfaction) is
				// same or better.
				if (Tools.isBetterFeasible(feasible[j], newFeasible)) {
					// Compute new fitness.
					double newFitness = problem.fitness(y, fitness[j],
							feasible[j], newFeasible);

					// Update agent in case of fitness improvement.
					if (Tools.isBetterFeasibleFitness(feasible[j], newFeasible,
							fitness[j], newFitness)) {
						// Update agent's position.
						Tools.copy(y, agents[j]);

						// Update agent's fitness.
						fitness[j] = newFitness;

						// Update agent's feasibility.
						feasible[j] = newFeasible;

						// Update population's best known position,
						// if feasibility is same or better and fitness is an
						// improvement.
						if (Tools.isBetterFeasibleFitness(gFeasible,
								newFeasible, gFitness, newFitness)) {
							g = agents[j];
							gFitness = newFitness;
							gFeasible = newFeasible;
						}
					}
				}

				// Trace fitness of best found solution.
				trace(i, gFitness, gFeasible);
			}
		}

		// Signal end of optimization run.
		problem.endOptimizationRun();

		// Return best-found solution and fitness.
		return new Result(g, gFitness, gFeasible, i);
	}

	/**
	 * Control parameters tuned for various optimization scenarios.
	 */
	public static class Parameters {
		/**
		 * Control parameters for use with Rand1Bin crossover.
		 * 
		 */
		public static class Rand1Bin {
			/**
			 * Control parameters for use with Rand1Bin crossover, No Dither.
			 * 
			 */
			public static class NoDither {
				/**
				 * Hand-tuned control parameters for use with Rand1Bin
				 * crossover, No Dither.
				 */
				public static final double[] HandTuned = { 300.0, 0.9, 0.5 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 2 dimensions and
				 * 400 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks2Dim400IterA = {
						13.0, 0.745, 0.9096 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 2 dimensions and
				 * 400 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks2Dim400IterB = {
						10.0, 0.4862, 1.1922 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 2 dimensions and
				 * 4000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks2Dim4000IterA = { 24,
						0.2515, 0.8905 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 2 dimensions and
				 * 4000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks2Dim4000IterB = {
						20.0, 0.7455, 0.9362 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 5 dimensions and
				 * 1000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks5Dim1000Iter = {
						17.0, 0.7122, 0.6301 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 5 dimensions and
				 * 10000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks5Dim10000Iter = {
						20.0, 0.6938, 0.9314 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 10 dimensions and
				 * 2000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks10Dim2000IterA = {
						28.0, 0.9426, 0.6607 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 10 dimensions and
				 * 2000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks10Dim2000IterB = {
						12.0, 0.2368, 0.6702 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 10 dimensions and
				 * 20000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks10Dim20000Iter = {
						18.0, 0.5026, 0.6714 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 20 dimensions and
				 * 40000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks20Dim40000Iter = {
						37.0, 0.9455, 0.6497 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for Ackley, Rastrigin, Rosenbrock, and
				 * Schwefel1-2 in 20 dimensions and 400000 fitness evaluations
				 * in one optimization run.
				 */
				public static final double[] FourBenchmarks20Dim400000Iter = {
						35.0, 0.4147, 0.5983 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 50 dimensions and
				 * 100000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks50Dim100000Iter = {
						48.0, 0.9784, 0.6876 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for Ackley, Rastrigin, Rosenbrock, and
				 * Schwefel1-2 in 100 dimensions and 200000 fitness evaluations
				 * in one optimization run.
				 */
				public static final double[] FourBenchmarks100Dim200000Iter = {
						46.0, 0.9565, 0.5824 };

				/**
				 * Mesh-tuned parameters, from mesh search when fixing CR=0.9
				 * with various combinations of benchmark problems and
				 * optimization run-lengths.
				 */
				public static final double[] ParametersMeshTuned = { 50.0, 0.9,
						0.6 };

				/**
				 * Control parameters tuned for four benchmark problems (Ackley,
				 * Rastrigin, Rosenbrock, Schwefel1-2) in 30 dimensions each and
				 * 600000 fitness evaluations in one optimization run.
				 */
				public static final double[] FourBenchmarks30Dim600000Iter = {
						75.0, 0.8803, 0.4717 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 30 dimensions and
				 * 6000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks30Dim6000Iter = {
						11.0, 0.0877, 0.6419 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems in 30 dimensions and
				 * 60000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks30Dim60000Iter = {
						19.0, 0.122, 0.4983 };

				/**
				 * Control parameters for use with Rand1Bin crossover, No
				 * Dither, tuned for all benchmark problems except Schwefel1-2
				 * in 30 dimensions and 60000 fitness evaluations in one
				 * optimization run.
				 */
				public static final double[] AllBenchmarks_NoSchwefel12_30Dim60000Iter = {
						19.0, 0.4616, 0.5314 };
			}

			/**
			 * Control parameters for use with Rand1Bin crossover, Jitter.
			 */
			public static class Jitter {
				/**
				 * Hand-tuned control parameters for use with Rand1Bin
				 * crossover, Jitter.
				 */
				public static final double[] HandTuned = { 50.0, 0.9, 0.5,
						0.0005 };

				/**
				 * Control parameters for use with Rand1Bin crossover, Jitter,
				 * tuned for all benchmark problems in 30 dimensions and 6000
				 * fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks30Dim6000Iter = {
						14.0, 0.0509, 0.0134, 1.0599 };

				/**
				 * Control parameters for use with Rand1Bin crossover, Jitter,
				 * tuned for all benchmark problems in 30 dimensions and 60000
				 * fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks30Dim60000Iter = {
						58.0, 0.9048, 0.3989, 0.3426 };
			}

			/**
			 * Control parameters for use with Rand1Bin crossover, VecDither.
			 */
			public static class VecDither {
				/**
				 * Hand-tuned control parameters for use with Rand1Bin
				 * crossover, VecDither.
				 */
				public static final double[] HandTuned = { 50.0, 0.9, 0.75,
						0.25 };

				/**
				 * Control parameters for use with Rand1Bin crossover,
				 * VecDither, tuned for all benchmark problems in 30 dimensions
				 * and 6000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks30Dim6000Iter = {
						14.0, 0.0835, 0.5536, 0.1395 };

				/**
				 * Control parameters for use with Rand1Bin crossover,
				 * VecDither, tuned for all benchmark problems in 30 dimensions
				 * and 60000 fitness evaluations in one optimization run.
				 */
				public static final double[] AllBenchmarks30Dim60000Iter = {
						102.0, 0.9637, 0.7876, 0.7292 };
			}
		}
	}
}
