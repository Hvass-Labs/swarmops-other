// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.optimizers;

import swarmops.Globals;
import swarmops.Optimizer;
import swarmops.Problem;
import swarmops.Result;
import swarmops.Tools;

/**
 * Particle Swarm Optimization (PSO) originally due to Eberhart et al. (1, 2).
 * This is a 'plain vanilla' variant which can have its parameters tuned (or
 * meta-optimized) to work well on a range of optimization problems. Generally,
 * however, the DE optimizer has been found to work better.
 * 
 * References:
 * 
 * (1) J. Kennedy and R. Eberhart. Particle swarm optimization. In Proceedings
 * of IEEE International Conference on Neural Networks, volume IV, pages
 * 1942-1948, Perth, Australia, 1995
 * 
 * (2) Y. Shi and R.C. Eberhart. A modified particle swarm optimizer. In
 * Proceedings of the IEEE International Conference on Evolutionary Computation,
 * pages 69-73, Anchorage, AK, USA, 1998.
 */
public class PSO extends Optimizer {
	/**
	 * Construct the object.
	 */
	public PSO() {
		super();
	}

	/**
	 * Construct the object.
	 * 
	 * @param problem
	 *            problem to optimize.
	 */
	public PSO(Problem problem) {
		super(problem);
	}

	/** Names of the control parameters. */
	private static final String[] parameterName = { "S", "Omega", "PhiP",
			"PhiG" };

	/** Lower boundary for the control parameters. */
	private static final double[] lowerBound = { 1.0, -2.0, -4.0, -4.0 };

	/** Upper boundary for the control parameters. */
	private static final double[] upperBound = { 300.0, 2.0, 4.0, 6.0 };

	@Override
	public double[] getDefaultParameters() {
		return Parameters.allBenchmarks30Dim60000Iter;
	}

	@Override
	public String getName() {
		return "PSO";
	}

	@Override
	public String[] getParameterName() {
		return parameterName;
	}

	@Override
	public double[] getLowerBound() {
		return lowerBound;
	}

	@Override
	public double[] getUpperBound() {
		return upperBound;
	}

	@Override
	public int getDimensionality() {
		return 4;
	}

	/**
	 * Get control parameter, number of agents aka. swarm-size.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public static int getNumAgents(double[] parameters) {
		return (int) Math.round(parameters[0]);
	}

	/**
	 * Get control parameter omega.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public double getOmega(double[] parameters) {
		return parameters[1];
	}

	/**
	 * Get control parameter phiP.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public double getPhiP(double[] parameters) {
		return parameters[2];
	}

	/**
	 * Get control parameter phiG.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public double getPhiG(double[] parameters) {
		return parameters[3];
	}

	@Override
	public Result optimize(double[] parameters) {
		assert parameters != null && parameters.length == getDimensionality();

		// Signal beginning of optimization run.
		problem.beginOptimizationRun();

		// Retrieve parameter specific to PSO method.
		int numAgents = getNumAgents(parameters);
		double omega = getOmega(parameters);
		double phiP = getPhiP(parameters); // phi1
		double phiG = getPhiG(parameters); // phi2

		assert numAgents >= 1;

		// Get problem-context.
		double[] lowerBound = problem.getLowerBound();
		double[] upperBound = problem.getUpperBound();
		double[] lowerInit = problem.getLowerInit();
		double[] upperInit = problem.getUpperInit();
		int n = problem.getDimensionality();

		// Allocate agent positions and associated fitness.
		double[][] agents = new double[numAgents][n];
		double[][] velocities = new double[numAgents][n];
		double[][] bestAgentPosition = new double[numAgents][n];
		double[] bestAgentFitness = new double[numAgents];
		boolean[] bestAgentFeasible = new boolean[numAgents];

		// Allocate velocity boundaries.
		double[] velocityLowerBound = new double[n];
		double[] velocityUpperBound = new double[n];

		// Iteration variables.
		int i, j, k;

		// Best-found position and fitness.
		double[] g = null;
		double gFitness = problem.getMaxFitness();
		boolean gFeasible = false;

		// Initialize velocity boundaries.
		for (k = 0; k < n; k++) {
			double range = Math.abs(upperBound[k] - lowerBound[k]);

			velocityLowerBound[k] = -range;
			velocityUpperBound[k] = range;
		}

		// Initialize all agents.
		// This counts as iterations below.
		for (j = 0; j < numAgents
				&& problem.continueOptimization(j, gFitness, gFeasible); j++) {
			// Refer to the j'th agent as x and v.
			double[] x = agents[j];
			double[] v = velocities[j];

			// Initialize velocity.
			Tools.initializeUniform(v, velocityLowerBound, velocityUpperBound);

			// Initialize agent-position in search-space.
			Tools.initializeUniform(x, lowerInit, upperInit);

			// Enforce constraints and evaluate feasibility.
			bestAgentFeasible[j] = problem.enforceConstraints(x);

			// Compute fitness of initial position.
			bestAgentFitness[j] = problem.fitness(x, bestAgentFeasible[j]);

			// Initialize best known position.
			// Contents must be copied because the agent
			// will likely move to worse positions.
			Tools.copy(x, bestAgentPosition[j]);

			// Update swarm's best known position.
			// This must reference the agent's best-known
			// position because the current position changes.
			if (Tools.isBetterFeasibleFitness(gFeasible, bestAgentFeasible[j],
					gFitness, bestAgentFitness[j])) {
				g = bestAgentPosition[j];
				gFitness = bestAgentFitness[j];
				gFeasible = bestAgentFeasible[j];
			}

			// Trace fitness of best found solution.
			trace(j, gFitness, gFeasible);
		}

		// Perform actual optimization iterations.
		for (i = numAgents; problem
				.continueOptimization(i, gFitness, gFeasible);) {
			for (j = 0; j < numAgents
					&& problem.continueOptimization(i, gFitness, gFeasible); j++, i++) {
				// Refer to the j'th agent as x and v.
				double[] x = agents[j];
				double[] v = velocities[j];
				double[] p = bestAgentPosition[j];

				// Pick random weights.
				double rP = Globals.random.nextUniform();
				double rG = Globals.random.nextUniform();

				// Update velocity.
				for (k = 0; k < n; k++) {
					v[k] = omega * v[k] + phiP * rP * (p[k] - x[k]) + phiG * rG
							* (g[k] - x[k]);
				}

				// Enforce velocity bounds before updating position.
				Tools.bound(v, velocityLowerBound, velocityUpperBound);

				// Update position.
				for (k = 0; k < n; k++) {
					x[k] = x[k] + v[k];
				}

				// Enforce constraints and evaluate feasibility.
				boolean newFeasible = problem.enforceConstraints(x);

				// Compute fitness if feasibility is same or better.
				if (Tools.isBetterFeasible(bestAgentFeasible[j], newFeasible)) {
					// Compute new fitness.
					double newFitness = problem.fitness(x, bestAgentFitness[j],
							bestAgentFeasible[j], newFeasible);

					// Update best-known position in case of fitness
					// improvement.
					if (Tools.isBetterFeasibleFitness(bestAgentFeasible[j],
							newFeasible, bestAgentFitness[j], newFitness)) {
						// Update best-known position.
						// Contents must be copied because the agent
						// will likely move to worse positions.
						Tools.copy(x, bestAgentPosition[j]);
						bestAgentFitness[j] = newFitness;

						// Update feasibility.
						bestAgentFeasible[j] = newFeasible;

						// Update swarm's best known position,
						// if feasibility is same or better and fitness is an
						// improvement.
						// This must reference the agent's best-known
						// position because the current position changes.
						if (Tools.isBetterFeasibleFitness(gFeasible,
								bestAgentFeasible[j], gFitness,
								bestAgentFitness[j])) {
							g = bestAgentPosition[j];
							gFitness = bestAgentFitness[j];
							gFeasible = bestAgentFeasible[j];
						}
					}
				}

				// Trace fitness of best found solution.
				trace(i, gFitness, gFeasible);
			}
		}

		// Signal end of optimization run.
		problem.endOptimizationRun();

		// Return best-found solution and fitness.
		return new Result(g, gFitness, gFeasible, i);
	}

	/**
	 * Control parameters tuned for various optimization scenarios.
	 */
	public static class Parameters {
		/**
		 * Hand-tuned control parameters.
		 */
		public static final double[] handTuned = { 50.0, 0.729, 1.49445,
				1.49445 };

		/**
		 * Control parameters tuned for all benchmark problems in 2 dimensions
		 * and 400 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks2Dim400IterA = { 25.0,
				0.3925, 2.5586, 1.3358 };

		/**
		 * Control parameters tuned for all benchmark problems in 2 dimensions
		 * and 400 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks2Dim400IterB = { 29.0,
				-0.4349, -0.6504, 2.2073 };

		/**
		 * Control parameters tuned for all benchmark problems in 2 dimensions
		 * and 4000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks2Dim4000IterA = { 156.0,
				0.4091, 2.1304, 1.0575 };

		/**
		 * Control parameters tuned for all benchmark problems in 2 dimensions
		 * and 4000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks2Dim4000IterB = { 237.0,
				-0.2887, 0.4862, 2.5067 };

		/**
		 * Control parameters tuned for all benchmark problems in 5 dimensions
		 * and 1000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks5Dim1000IterA = { 63.0,
				-0.3593, -0.7238, 2.0289 };

		/**
		 * Control parameters tuned for all benchmark problems in 5 dimensions
		 * and 1000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks5Dim1000IterB = { 47.0,
				-0.1832, 0.5287, 3.1913 };

		/**
		 * Control parameters tuned for all benchmark problems in 5 dimensions
		 * and 10000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks5Dim10000IterA = { 223.0,
				-0.3699, -0.1207, 3.3657 };

		/**
		 * Control parameters tuned for all benchmark problems in 5 dimensions
		 * and 10000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks5Dim10000IterB = { 203.0,
				0.5069, 2.5524, 1.0056 };

		/**
		 * Control parameters tuned for all benchmark problems in 10 dimensions
		 * and 2000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks10Dim2000IterA = { 63.0,
				0.6571, 1.6319, 0.6239 };

		/**
		 * Control parameters tuned for all benchmark problems in 10 dimensions
		 * and 2000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks10Dim2000IterB = { 204.0,
				-0.2134, -0.3344, 2.3259 };

		/**
		 * Control parameters tuned for all benchmark problems in 10 dimensions
		 * and 20000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks10Dim20000Iter = { 53.0,
				-0.3488, -0.2746, 4.8976 };

		/**
		 * Control parameters tuned for all benchmark problems in 20 dimensions
		 * and 40000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks20Dim40000Iter = { 69,
				-0.4438, -0.2699, 3.395 };

		/**
		 * Control parameters tuned for Ackley, Rastrigin, Rosenbrock, and
		 * Schwefel1-2 in 20 dimensions and 400000 fitness evaluations in one
		 * optimization run.
		 */
		public static final double[] fourBenchmarks20Dim400000IterA = { 149.0,
				-0.3236, -0.1136, 3.9789 };

		/**
		 * Control parameters tuned for Ackley, Rastrigin, Rosenbrock, and
		 * Schwefel1-2 in 20 dimensions and 400000 fitness evaluations in one
		 * optimization run.
		 */
		public static final double[] fourBenchmarks20Dim400000IterB = { 60.0,
				-0.4736, -0.97, 3.7904 };

		/**
		 * Control parameters tuned for Ackley, Rastrigin, Rosenbrock, and
		 * Schwefel1-2 in 20 dimensions and 400000 fitness evaluations in one
		 * optimization run.
		 */
		public static final double[] fourBenchmarks20Dim400000IterC = { 256.0,
				-0.3499, -0.0513, 4.9087 };

		/**
		 * Control parameters tuned for all benchmark problems in 50 dimensions
		 * and 100000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks50Dim100000Iter = { 106,
				-0.2256, -0.1564, 3.8876 };

		/**
		 * Control parameters tuned for Ackley, Rastrigin, Rosenbrock, and
		 * Schwefel1-2 in 100 dimensions and 200000 fitness evaluations in one
		 * optimization run.
		 */
		public static final double[] fourBenchmarks100Dim200000Iter = { 161.0,
				-0.2089, -0.0787, 3.7637 };

		/**
		 * Control parameters tuned for all benchmark problems in 30 dimensions
		 * and 60000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks30Dim60000Iter = { 134.0,
				-0.1618, 1.8903, 2.1225 };

		/**
		 * Control parameters tuned for all benchmark problems in 30 dimensions
		 * and 600000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks30Dim600000Iter = { 95.0,
				-0.6031, -0.6485, 2.6475 };

		/**
		 * Control parameters tuned for Ackley in 30 dimensions and 60000
		 * fitness evaluations in one optimization run.
		 */
		public static final double[] ackley_30Dim60000Iter = { 24.0, -0.6421,
				-3.9845, 0.2583 };

		/**
		 * Control parameters tuned for Rastrigin in 30 dimensions and 60000
		 * fitness evaluations in one optimization run.
		 */
		public static final double[] rastrigin_30Dim60000Iter = { 53.0,
				-1.3131, -0.709, -0.5648 };

		/**
		 * Control parameters tuned for Rosenbrock in 30 dimensions and 60000
		 * fitness evaluations in one optimization run.
		 */
		public static final double[] rosenbrock_30Dim60000Iter = { 2.0, 0.7622,
				1.3619, 3.4249 };

		/**
		 * Control parameters tuned for Schwefel1-2 in 30 dimensions and 60000
		 * fitness evaluations in one optimization run.
		 */
		public static final double[] schwefel12_30Dim60000Iter = { 119.0,
				-0.3718, -0.2031, 3.2785 };

		/**
		 * Control parameters tuned for Sphere and Rosenbrock problems in 30
		 * dimensions each and 60000 fitness evaluations in one optimization
		 * run.
		 */
		public static final double[] sphereRosenbrock_30Dim60000Iter = { 84.0,
				-0.3036, -0.0075, 3.973 };

		/**
		 * Control parameters tuned for Rastrigin and Schwefel1-2 problems in 30
		 * dimensions each and 60000 fitness evaluations in one optimization
		 * run.
		 */
		public static final double[] rastriginSchwefel12_30Dim60000Iter = {
				82.0, -0.3794, -0.2389, 3.5481 };

		/**
		 * Control parameters tuned for Rastrigin and Schwefel1-2 problems in 30
		 * dimensions each and 600000 fitness evaluations in one optimization
		 * run.
		 */
		public static final double[] rastriginSchwefel12_30Dim600000Iter = {
				104.0, -0.4565, -0.1244, 3.0364 };

		/**
		 * Control parameters tuned for QuarticNoise, Sphere, Step problems in
		 * 30 dimensions each and 60000 fitness evaluations in one optimization
		 * run.
		 */
		public static final double[] quarticNoiseSphereStep_30Dim60000Iter = {
				50.0, -0.3610, 0.7590, 2.2897 };
	}
}
