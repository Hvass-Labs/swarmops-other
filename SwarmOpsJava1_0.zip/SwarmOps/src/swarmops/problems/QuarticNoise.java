// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.problems;

import swarmops.Globals;

/** The QuarticNoise benchmark problem. */
public class QuarticNoise extends Benchmark {
	/**
	 * Construct the object.
	 * 
	 * @param dimensionality
	 *            dimensionality of the search-space.
	 * 
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 */
	public QuarticNoise(int dimensionality, int maxIterations)
	{
		super(dimensionality, -1.28, 1.28, 0.64, 1.28, maxIterations);
	}
	
	@Override
	public String getName() {
		return "QuarticNoise";
	}

	@Override
	public double getMinFitness() {
		return 0;
	}

	@Override
    public double fitness(double[] x)
    {
    	int n = getDimensionality();

    	assert x != null && x.length == n;

        double value = 0;

        for (int i = 0; i < n; i++)
        {
            double elm = x[i];
            double elm2 = elm * elm;
            double elm4 = elm2 * elm2;

            value += ((double)(i + 1)) * elm4 + Globals.random.nextUniform();
        }

        return value;
    }
}
