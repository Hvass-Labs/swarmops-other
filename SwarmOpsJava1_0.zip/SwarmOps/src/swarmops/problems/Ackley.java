// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.problems;

/** The Ackley benchmark problem. */
public class Ackley extends Benchmark {
	/**
	 * Construct the object.
	 * 
	 * @param dimensionality
	 *            dimensionality of the search-space.
	 * 
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 */
	public Ackley(int dimensionality, int maxIterations) {
		super(dimensionality, -30, 30, 15, 30, maxIterations);
	}

	@Override
	public String getName() {
		return "Ackley";
	}

	@Override
	public double getMinFitness() {
		return 0;
	}

	@Override
	public double fitness(double[] x) {
		int n = getDimensionality();

		assert x != null && x.length == n;

		double value = Math.E + 20 - 20 * Math.exp(-0.2 * sqrtSum(x))
				- cosSum(x);

		// Rounding errors may cause negative fitness to occur even
		// though the mathematical global minimum has fitness zero.
		// Ensure this still works with meta-optimization which
		// requires non-negative fitness.
		if (value < 0) {
			value = 0;
		}

		return value;
	}

	@Override
	public boolean hasGradient() {
		return true;
	}

	@Override
	public int gradient(double[] x, double[] v) {
		int n = getDimensionality();

		assert x != null && x.length == n;
		assert v != null && v.length == n;

		double sqrtSum = sqrtSum(x);
		double cosSum = cosSum(x);

		double DimRec = 1.0 / n;

		for (int i = 0; i < n; i++) {
			double elm = x[i];

			v[i] = 4 * DimRec * Math.exp(-0.2 * sqrtSum) * elm / sqrtSum
					+ cosSum * Math.sin(Math.PI * 2 * elm) * Math.PI * 2
					* DimRec;
		}

		return 0;
	}

	/**
	 * Helper-method used in both the Fitness- and Gradient-methods.
	 */
	private double sqrtSum(double[] x) {
		double sum = 0;
		int n = x.length;

		for (int i = 0; i < n; i++) {
			double elm = x[i];

			sum += elm * elm;
		}

		return Math.sqrt(sum / n);
	}

	/**
	 * Helper-method used in both the Fitness- and Gradient-methods.
	 */
	private double cosSum(double[] x) {
		double sum = 0;
		int n = x.length;

		for (int i = 0; i < n; i++) {
			double elm = x[i];
			sum += Math.cos(Math.PI * 2 * elm);
		}

		return Math.exp(sum / n);
	}
}
