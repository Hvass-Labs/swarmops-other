// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.problems;

/** The Schwefel2-22 benchmark problem. */
public class Schwefel222 extends Benchmark {
	/**
	 * Construct the object.
	 * 
	 * @param dimensionality
	 *            dimensionality of the search-space.
	 * 
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 */
	public Schwefel222(int dimensionality, int maxIterations) {
		super(dimensionality, -10, 10, 5, 10, maxIterations);
	}

	@Override
	public String getName() {
		return "Schwefel2-22";
	}

	@Override
	public double getMinFitness() {
		return 0;
	}

	@Override
	public double fitness(double[] x) {
		int n = getDimensionality();

		assert x != null && x.length == n;

		double sum = 0;
		double product = 1;

		for (int i = 0; i < n; i++) {
			double absElm = Math.abs(x[i]);

			sum += absElm;
			product *= absElm;
		}

		return sum + product;
	}
}
