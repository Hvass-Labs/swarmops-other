// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.problems;

/** The Rastrigin benchmark problem. */
public class Rastrigin extends Benchmark {
	/**
	 * Construct the object.
	 * 
	 * @param dimensionality
	 *            dimensionality of the search-space.
	 * 
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 */
	public Rastrigin(int dimensionality, int maxIterations)
	{
		super(dimensionality, -5.12, 5.12, 2.56, 5.12, maxIterations);
	}
	
	@Override
	public String getName() {
		return "Rastrigin";
	}

	@Override
	public double getMinFitness() {
		return 0;
	}

	@Override
    public double fitness(double[] x)
    {
    	int n = getDimensionality();

    	assert x != null && x.length == n;

        double value = 0;

        for (int i = 0; i < n; i++)
        {
            double elm = x[i];

            value += elm * elm + 10 - 10 * Math.cos(Math.PI * 2 * elm);
        }

        return value;
    }

	@Override
    public boolean hasGradient()
    {
    	return true;
    }

	@Override
    public int gradient(double[] x, double[] v)
    {
    	int n = getDimensionality();
    	
        assert x != null && x.length == n;
        assert v != null && v.length == n;

        for (int i = 0; i < n; i++)
        {
            double elm = x[i];
            
            v[i] = 2 * elm + Math.PI * 2 * 10 * Math.sin(Math.PI * 2 * elm);
        }

        return 0;
    }
}
