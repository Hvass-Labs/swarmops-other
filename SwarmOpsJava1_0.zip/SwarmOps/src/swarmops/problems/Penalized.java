// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.problems;

/** Base-class for penalized benchmark problems. */
public abstract class Penalized extends Benchmark {
	/**
	 * Construct the object.
	 * 
	 * @param dimensionality
	 *            dimensionality of the search-space.
	 * @param lowerBound
	 *            lower search-space boundary.
	 * @param upperBound
	 *            upper search-space boundary.
	 * @param lowerInit
	 *            lower initialization boundary.
	 * @param upperInit
	 *            upper initialization boundary.
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 */
	public Penalized(int dimensionality, double lowerBound, double upperBound,
			double lowerInit, double upperInit, int maxIterations) {
		super(dimensionality, lowerBound, upperBound, lowerInit, upperInit,
				maxIterations);
	}

	/**
	 * Helper-method for Penalized benchmark problems.
	 */
	protected double u(double x, double a, double k, double m) {
		double value;

		if (x < -a) {
			value = k * Math.pow(-x - a, m);
		} else if (x > a) {
			value = k * Math.pow(x - a, m);
		} else {
			value = 0;
		}

		return value;
	}
}
