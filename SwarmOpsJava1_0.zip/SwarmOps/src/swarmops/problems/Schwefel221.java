// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.problems;

/** The Schwefel2-21 benchmark problem. */
public class Schwefel221 extends Benchmark {
	/**
	 * Construct the object.
	 * 
	 * @param dimensionality
	 *            dimensionality of the search-space.
	 * 
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 */
	public Schwefel221(int dimensionality, int maxIterations)
	{
		super(dimensionality, -100, 100, 50, 100, maxIterations);
	}
	
	@Override
	public String getName() {
		return "Schwefel2-21";
	}

	@Override
	public double getMinFitness() {
		return 0;
	}

	@Override
    public double fitness(double[] x)
    {
    	int n = getDimensionality();

    	assert x != null && x.length == n;

        double maxValue = Math.abs(x[0]);

        for (int i = 1; i < n; i++)
        {
            double elm = Math.abs(x[i]);

            if (elm > maxValue)
            {
                maxValue = elm;
            }
        }

        return maxValue;
    }
}
