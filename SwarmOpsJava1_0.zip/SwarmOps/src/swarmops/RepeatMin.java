// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Performs a number of optimization runs and returns the minimum fitness found.
 * Respects feasibility (constraint satisfaction.)
 * 
 * This does NOT allow for Preemptive Fitness Evaluation!
 */
public class RepeatMin extends Repeat {
	/**
	 * Construct the object.
	 * 
	 * @param optimizer
	 *            optimizer to use.
	 * @param numRuns
	 *            number of optimization runs to perform.
	 */
	public RepeatMin(Optimizer optimizer, int numRuns) {
		super(optimizer, numRuns);
	}

	@Override
	public String getName() {
		return "RepeatMin(" + optimizer.getName() + ")";
	}

	@Override
	public double getMinFitness() {
		return optimizer.getMinFitness();
	}

	@Override
	public double fitness(double[] parameters, double fitnessLimit) {
		// Best fitness found so far is initialized to the worst possible
		// fitness.
		double fitness = optimizer.getMaxFitness();

		// Best feasibility found so far is initialized to the worst possible
		// (infeasible).
		boolean feasible = false;

		// Perform a number of optimization runs.
		for (int i = 0; i < numRuns; i++) {
			// Perform one optimization run.
			Result result = optimizer.optimize(parameters, fitnessLimit);

			// Update the best fitness found so far, if improvement.
			if (Tools.isBetterFeasibleFitness(feasible, result.feasible,
					fitness, result.fitness)) {
				fitness = result.fitness;
				feasible = result.feasible;
			}
		}

		return fitness;
	}
}
