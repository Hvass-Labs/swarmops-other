// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Log best solutions found during optimization, that is, log parameters and
 * their associated fitness. Transparently wraps around a problem-object.
 */
public class LogSolutions extends ProblemWrapper {
	/**
	 * Create the object.
	 * 
	 * @param problem
	 *            problem-object to be wrapped.
	 * @param capacity
	 *            log capacity.
	 * @param onlyFeasible
	 *            only log feasible solutions.
	 */
	public LogSolutions(Problem problem, int capacity, boolean onlyFeasible) {
		super(problem);

		this.capacity = capacity;
		this.onlyFeasible = onlyFeasible;

		log = new ArrayList<Solution>(capacity);
	}

	/**
	 * Maximum capacity of log.
	 */
	public final int capacity;

	/**
	 * Only log feasible solutions.
	 */
	public final boolean onlyFeasible;

	/**
	 * Log of candidate solutions.
	 */
	public ArrayList<Solution> log;

	/**
	 * Clear the log.
	 */
	public void clear() {
		log.clear();
	}

	@Override
	public String getName() {
		return "LogSolutions (" + problem.getName() + ")";
	}

	@Override
	public double fitness(double[] parameters, double fitnessLimit,
			boolean oldFeasible, boolean newFeasible) {
		// Compute the fitness measure by passing the
		// given parameters to the wrapped problem, and if
		// candidate solution is an improvement then log
		// the results.

		double fitness = problem.fitness(parameters, fitnessLimit, oldFeasible,
				newFeasible);

		// Log solutions. If feasibility is required then only log feasible
		// solutions.
		if (!onlyFeasible || newFeasible) {
			// Log solutions with better fitness and feasibility.
			if (Tools.isBetterFeasibleFitness(oldFeasible, newFeasible,
					fitnessLimit, fitness)) {
				// Ensure log does not exceed desired capacity.
				if (log.size() >= capacity) {
					// Assume log is sorted in ascending (worsening) order.
					// Remove worst from the log.
					log.remove(log.size() - 1);
				}

				Solution candidateSolution = new Solution(parameters, fitness,
						newFeasible);

				// Add new solution to the log.
				log.add(candidateSolution);

				// Sort log according to fitness.
				// This could be implemented more efficiently
				// but it is not crucial for runtime performance
				// so this simple implementation is sufficient.
				Collections.sort(log);
			}
		}

		return fitness;
	}
}
