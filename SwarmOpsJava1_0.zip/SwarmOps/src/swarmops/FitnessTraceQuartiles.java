// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import swarmops.statistics.Quartiles;

/**
 * Store fitness-values at intervals during optimization runs and write their quartiles to a file afterwards. This only supports a fixed number of optimization runs and iterations per run which must therefore be known in advance. Keep the number of intervals small because it requires much memory.
 */
public class FitnessTraceQuartiles extends FitnessTrace {
	/**
	 * Construct a new object.
	 * 
	 * @param numRuns number of optimization runs to be performed.
	 * @param numIterations number of iterations per run.
	 * @param numIntervals approximate number of intervals to show quartiles.
	 */
	public FitnessTraceQuartiles(int numRuns, int numIterations,
			int numIntervals) {
		this(numRuns, numIterations, numIntervals, null);
	}

	/**
	 * Construct a new object.
	 * 
	 * @param numRuns number of optimization runs to be performed.
	 * @param numIterations number of iterations per run.
	 * @param numIntervals approximate number of intervals to show quartiles.
	 * @param chainedFitnessTrace
	 *            chained FitnessTrace object.
	 */
	public FitnessTraceQuartiles(int numRuns, int numIterations,
			int numIntervals, FitnessTrace chainedFitnessTrace) {
		super(chainedFitnessTrace, numIterations, numIntervals, 0.5);

		this.numIterations = numIterations;

		// Allocate trace.
		trace = new ArrayList<ArrayList<Double>>(maxIntervals);
		for (int i = 0; i < maxIntervals; i++) {
			trace.add(new ArrayList<Double>(numRuns));
		}
	}

	/**
	 * Number of iterations per optimization run being fitness-traced.
	 */
	public int numIterations;

	/**
	 * Clear the stored fitness trace.
	 */
	public void clear() {
		for (int i = 0; i < trace.size(); i++) {
			trace.get(i).clear();
		}
	}

	@Override
	protected void log(int index, double fitness, boolean feasible) {
		trace.get(index).add(fitness);
	}

	@Override
	public void write(Writer writer) throws IOException {
		writer.write(String.format("# Iteration\tMin\tQ1\tMedian\tQ3\tMax%n%n"));

		for (int i = 0; i < trace.size(); i++) {
			Quartiles quartiles = new Quartiles();

			Double[] traceArray = new Double[trace.get(i).size()];
			trace.get(i).toArray(traceArray);

			if (traceArray.length > 0) {
				quartiles.computeUnsortedInplace(traceArray);

				writer.write(String.format("%d %g %g %g %g %g%n", iteration(i),
						quartiles.getMin(), quartiles.getQ1(),
						quartiles.getMedian(), quartiles.getQ3(),
						quartiles.getMax()));
			} else {
				break;
			}
		}

		writer.close();
	}

	/**
	 * Matrix for storage of the fitness trace.
	 */
	protected ArrayList<ArrayList<Double>> trace;
}
