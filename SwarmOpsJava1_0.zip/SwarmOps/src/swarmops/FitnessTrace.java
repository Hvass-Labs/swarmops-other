// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

import java.io.Writer;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Base-class for tracing fitness progress during optimization.
 */
public abstract class FitnessTrace {
	/**
	 * Construct a new object.
	 */
	public FitnessTrace(FitnessTrace chainedFitnessTrace, int numIterations,
			int numIntervals, double offset) {
		this.chainedFitnessTrace = chainedFitnessTrace;

		// The number of intervals at which to log/show fitness cannot
		// be greater than the number of optimization iterations.
		int intervals = Math.min(numIntervals, numIterations);

		// The stride is the number of optimization iterations that each
		// interval is made up of.
		stride = numIterations / intervals;

		// Offset for the first fitness log.
		offset = (int) (offset * stride);

		// The maximum number of intervals at which to log the fitness.
		// Consider numIterations==10, Offset==0, Stride==3, this requires
		// logging at iterations 0, 3, 6, 9. That is, a total of four log
		// entries. The reason that Ceiling is used is that
		// (numIterations - Offset) / Stride == 10 / 3 == 3 using integer
		// rounding.
		maxIntervals = (int) Math.ceil((double) (numIterations - offset)
				/ stride);
	}

	/**
	 * Number of intervals during optimization at which to log and show fitness.
	 */
	public int maxIntervals;

	/**
	 * Offset for showing the first trace-element.
	 */
	public int offset;

	/**
	 * Stride between the intervals for showing trace-elements.
	 */
	public int stride;

	/**
	 * Chained fitness trace.
	 */
	protected FitnessTrace chainedFitnessTrace;

	/**
	 * Add a fitness value to the trace at the given iteration number.
	 * 
	 * @param iteration
	 *            iteration number of fitness.
	 * @param fitness
	 *            fitness value to be traced.
	 * @param feasible
	 *            feasibility (constraint satisfaction) to be traced.
	 */
	public void add(int iteration, double fitness, boolean feasible) {
		// If the optimization-iteration falls on an interval then log the
		// fitness.
		if ((iteration - offset) % stride == 0) {
			int index = (iteration - offset) / stride;

			if (index < maxIntervals) {
				log(index, fitness, feasible);
			}
		}

		// Call chained fitness-tracer.
		if (chainedFitnessTrace != null) {
			chainedFitnessTrace.add(iteration, fitness, feasible);
		}
	}

	/**
	 * Write fitness-trace to a TextWriter stream.
	 * 
	 * @throws IOException
	 */
	public abstract void write(Writer writer) throws IOException;

	/**
	 * Write fitness-trace to a file.
	 * 
	 * @param filename
	 *            name of file.
	 * @throws IOException
	 */
	public void writeToFile(String filename) throws IOException {
		Writer writer = new FileWriter(filename);

		write(writer);
	}

	/**
	 * Log a fitness.
	 * 
	 * @param index
	 *            index into fitness-trace, mapped from optimization iteration.
	 * @param fitness
	 *            fitness value to log.
	 * @param feasible
	 *            feasibility (constraint satisfaction) to log.
	 */
	protected abstract void log(int index, double fitness, boolean feasible);

	/**
	 * Map fitness-trace index to optimization iteration.
	 */
	protected int iteration(int index) {
		return index * stride + offset + 1;
	}
}
