// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.statistics;

import java.util.Arrays;

/**
 * Compute quartiles.
 */
public class Quartiles {
	/**
	 * Construct the object.
	 */
	public Quartiles() {
		clear();
	}

	/**
	 * Minimum element.
	 */
	private Double min;

	/**
	 * Maximum element.
	 */
	private Double max;

	/**
	 * Median, if array is odd-length the middle element is the median,
	 * otherwise if array is even-length the median is the mean of the two
	 * middle elements.
	 */
	private Double median;

	/**
	 * First quartile, if between two elements the one closest to the median is
	 * taken.
	 */
	private Double q1;

	/**
	 * Third quartile, if between two elements the one closest to the median is
	 * taken.
	 */
	private Double q3;

	/**
	 * Inter-quartile range, Q3-Q1.
	 */
	private Double iqr;

	/**
	 * Return min.
	 */
	public Double getMin() {
		return min;
	}

	/**
	 * Return max.
	 */
	public Double getMax() {
		return max;
	}

	/**
	 * Return median.
	 */
	public Double getMedian() {
		return median;
	}

	/**
	 * Return first quartile.
	 */
	public Double getQ1() {
		return q1;
	}

	/**
	 * Return second quartile, same as median.
	 */
	public Double getQ2() {
		return getMedian();
	}

	/**
	 * Return third quartile.
	 */
	public Double getQ3() {
		return q3;
	}

	/**
	 * Return inter-quartile-range, q3-q1.
	 */
	public Double getIQR() {
		return iqr;
	}

	/**
	 * Clear all quartiles.
	 */
	public void clear() {
		min = null;
		max = null;
		median = null;
		q1 = null;
		q3 = null;
		iqr = null;
	}

	/**
	 * Compute quartiles for a sorted array of values.
	 * 
	 * @param x
	 *            sorted array of values.
	 */
	public void compute(Double[] x) {
		if (x.length > 0) {
			computeMedian(x);
			computeQ1(x);
			computeQ3(x);

			iqr = q3 - q1;

			min = x[0];
			max = x[x.length - 1];
		} else {
			clear();
		}
	}

	/**
	 * Compute quartiles for an unsorted array of values. Sorts the source-array
	 * inplace.
	 * 
	 * @param x
	 *            unsorted array of values.
	 */
	public void computeUnsortedInplace(Double[] x) {
		Arrays.sort(x);

		compute(x);
	}

	/**
	 * Compute first quartile.
	 * 
	 * @param x
	 *            sorted array of values.
	 */
	void computeQ1(Double[] x) {
		double indexD = (x.length + 1) * 0.25;
		int index = (int) Math.ceil(indexD);

		q1 = x[index - 1];
	}

	/**
	 * Compute median.
	 * 
	 * @param x
	 *            sorted array of values.
	 */
	void computeMedian(Double[] x) {
		int index = (x.length - 1) / 2;

		median = (x.length % 2 == 0) ? (0.5 * (x[index] + x[index + 1]))
				: (x[index]);
	}

	/**
	 * Compute third quartile.
	 * 
	 * @param x
	 *            sorted array of values.
	 */
	void computeQ3(Double[] x) {
		double indexD = (x.length + 1) * 0.75;
		int index = (int) Math.floor(indexD);

		q3 = x[index - 1];
	}
}
