// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.statistics;

/**
 * Compute statistical measures in accumulating manner, incl. mean, variance,
 * std.deviation, min, max.
 */
public class StatisticsAccumulator {
	/**
	 * Construct the object.
	 */
	public StatisticsAccumulator() {
		clear();
	}

	/**
	 * Accumulator variable.
	 */
	private double q;

	/**
	 * Number of accumulations performed so far.
	 */
	private double count;

	/**
	 * Mean.
	 */
	private double mean;

	/**
	 * Min.
	 */
	private double min;

	/**
	 * Max.
	 */
	private double max;

	/**
	 * Return number of accumulations performed so far.
	 */
	public double getCount() {
		return count;
	}

	/**
	 * Return mean of accumulated data.
	 */
	public double getMean() {
		return mean;
	}

	/**
	 * Return min of accumulated data.
	 */
	public double getMin() {
		return min;
	}

	/**
	 * Return max of accumulated data.
	 */
	public double getMax() {
		return max;
	}

	/**
	 * Variance.
	 */
	public double getVariance() {
		return q / count;
	}

	/**
	 * Standard deviation.
	 */
	public double getStandardDeviation() {
		return Math.sqrt(getVariance());
	}

	/**
	 * Input data and accumulate variance.
	 * 
	 * @param x
	 *            data to input.
	 */
	public void accumulate(double x) {
		double meanOld = mean;

		mean = mean + (x - mean) / (count + 1);
		q = q + (x - meanOld) * (x - mean);

		count++;

		min = Math.min(min, x);
		max = Math.max(max, x);
	}

	/**
	 * Clear the accumulation variables.
	 */
	public void clear() {
		mean = 0;
		q = 0;
		count = 0;

		min = Double.MAX_VALUE;
		max = Double.MIN_VALUE;
	}
}
