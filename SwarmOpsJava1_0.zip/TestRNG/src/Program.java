import swarmops.random.*;
import swarmops.statistics.StatisticsAccumulator;

/**
 * Basic testing of pseudo-random number generators to check it works as
 * expected. Does not perform advanced statistical tests.
 */
public class Program {
	static final boolean testBool = false;

	static final int numIterations = 10;

	static final double gaussMean = 0;
	static final double gaussDeviation = 1;

	static final int meanIterations = 10000;

	static final int boolIterations = 10000;

	static final int indexIterations = 10000;
	static final int maxIndex = 8;
	static int[] indexCounts = new int[maxIndex];

	static final int randSetSize = 8;
	static final int setIterations = 8;
	static final int randSetExclude = randSetSize / 2;
	static final int setIterations2 = 10000;
	static int[] setCounts = new int[randSetSize];

	static final int setDistributedSize = 5;
	static final int indexDistributionIterations = 100000;
	static double[] indexProbabilities = new double[setDistributedSize];
	static int[] indexDistributionCounts = new int[setDistributedSize];

	static StatisticsAccumulator statAcc = new StatisticsAccumulator();

	static void printPoint(Disk disk) {
		System.out.printf("(%f, %f)\n", disk.x, disk.y);
		System.out.printf("Norm: %f\n",
				Math.sqrt(disk.x * disk.x + disk.y * disk.y));
	}

	static void zeroCounts(int[] counts) {
		for (int i = 0; i < counts.length; i++) {
			counts[i] = 0;
		}
	}

	static void printCounts(int[] counts) {
		for (int i = 0; i < counts.length; i++) {
			System.out.printf("Index: %d Count: %d\n", i, counts[i]);
		}
	}

	static void printDistributionCounts() {
		for (int i = 0; i < indexDistributionCounts.length; i++) {
			System.out.printf("Index: %d Probability: %.4f Frequency: %.4f", i,
					indexProbabilities[i], (double) indexDistributionCounts[i]
							/ indexDistributionIterations);
		}
	}

	static void initSetProbabilities(Random rng) {
		int i;
		double sum = 0;

		// Initialize probabilities to random values.
		for (i = 0; i < indexProbabilities.length; i++) {
			double r = rng.nextUniform();
			indexProbabilities[i] = r;
			sum += r;
		}

		// Normalize so sum of probabilities is one.
		for (i = 0; i < indexProbabilities.length; i++) {
			indexProbabilities[i] /= sum;
		}
	}

	static void doTest(Random rng) {
		int i;

		System.out.printf("RNG name: %s\n", rng.getName());
		System.out.printf("\n");

		System.out.printf("nextUniform()\n");
		for (i = 0; i < numIterations; i++) {
			System.out.printf("%f\n", rng.nextUniform());
		}
		System.out.printf("\n");

		System.out.printf("nextUniform(-3, -1)\n");
		for (i = 0; i < numIterations; i++) {
			System.out.printf("%f\n", rng.nextUniform(-3, -1));
		}
		System.out.printf("\n");

		System.out.printf("nextUniform(-2, 2)\n");
		for (i = 0; i < numIterations; i++) {
			System.out.printf("%f\n", rng.nextUniform(-2, 2));
		}
		System.out.printf("\n");

		System.out.printf("nextUniform(3, 5)\n");
		for (i = 0; i < numIterations; i++) {
			System.out.printf("%f\n", rng.nextUniform(3, 5));
		}
		System.out.printf("\n");

		System.out.printf("nextGaussian(%f, %f)\n", gaussMean, gaussDeviation);
		for (i = 0; i < numIterations; i++) {
			System.out.printf("%f\n",
					rng.nextGaussian(gaussMean, gaussDeviation));
		}
		System.out.printf("\n");

		statAcc.clear();
		for (i = 0; i < meanIterations; i++) {
			statAcc.accumulate(rng.nextUniform());
		}
		// Expected mean 0.5, std.dev. 0,2887
		System.out.printf("Mean of %d x nextUniform(): %.4f, std.dev.: %.4f\n",
				meanIterations, statAcc.getMean(),
				statAcc.getStandardDeviation());
		System.out.printf("\n");

		statAcc.clear();
		for (i = 0; i < meanIterations; i++) {
			statAcc.accumulate(rng.nextGaussian(0, 1));
		}
		// Expected mean 0, std.dev. 1
		System.out.printf(
				"Mean of %d x nextGaussian(0, 1): %.4f, std.dev: %.4f\n",
				meanIterations, statAcc.getMean(),
				statAcc.getStandardDeviation());
		System.out.printf("\n");

		System.out.printf("Disk()\n");
		printPoint(new Disk(rng));
		System.out.printf("\n");

		if (testBool) {
			System.out.printf("nextBoolean()\n");
			int countTrue = 0;
			int countFalse = 0;
			for (i = 0; i < boolIterations; i++) {
				if (rng.nextBoolean()) {
					countTrue++;
				} else {
					countFalse++;
				}
			}
			System.out.printf("True: %d\n", countTrue);
			System.out.printf("False: %d\n", countFalse);
			System.out.printf("\n");
		}

		System.out.printf("nextIndex(%d)\n", maxIndex);
		zeroCounts(indexCounts);
		for (i = 0; i < indexIterations; i++) {
			int idx = rng.nextIndex(maxIndex);

			indexCounts[idx] += 1;
		}
		printCounts(indexCounts);
		System.out.printf("\n");

		System.out.printf("nextIndex2(%d, ...)\n", maxIndex);
		zeroCounts(indexCounts);
		for (i = 0; i < indexIterations; i++) {
			int[] idx = rng.nextIndex2(maxIndex);
			int idx1 = idx[0];
			int idx2 = idx[1];

			assert idx1 != idx2;

			indexCounts[idx1] += 1;
			indexCounts[idx2] += 1;
		}
		printCounts(indexCounts);
		System.out.printf("\n");

		RandomSet randSet = new RandomSet(rng, randSetSize);

		System.out.printf("RandSet.reset()\n");
		randSet.reset();

		System.out.printf(
				"RandSet.draw() with set of size %d and %d iterations\n",
				randSetSize, setIterations / 2);
		for (i = 0; i < setIterations / 2; i++) {
			System.out.printf("%d\n", randSet.draw());
		}
		System.out.printf("\n");

		System.out.printf("RandSet.reset()\n");
		System.out.printf("RandSet.draw() with set of size %d\n", randSetSize);
		randSet.reset();
		for (i = 0; i < setIterations; i++) {
			System.out.printf("%d\n", randSet.draw());
		}
		System.out.printf("\n");

		// randSet.draw(); // Assertion fails.

		System.out.printf("RandomSet.resetExclude(%d)\n", randSetExclude);
		System.out
				.printf("RandomSet.draw() with set of size %d\n", randSetSize);
		randSet.resetExclude(randSetExclude);
		for (i = 0; i < setIterations - 1; i++) {
			System.out.printf("%d\n", randSet.draw());
		}
		System.out.printf("\n");

		// randSet.draw(); // Assertion fails.

		zeroCounts(setCounts);
		System.out
				.printf("RandomSet.draw() with set of size %d\n", randSetSize);
		for (i = 0; i < setIterations2; i++) {
			randSet.reset();

			while (randSet.getSize() > 0) {
				int idx = randSet.draw();

				setCounts[idx] += 1;
			}
		}
		printCounts(setCounts);
		System.out.printf("\n");
	}

	static void test(Random rng) {
		long t1 = System.currentTimeMillis();

		doTest(rng);

		long t2 = System.currentTimeMillis();

		System.out.printf("Time usage: %.2f seconds\n",
				(double) (t2 - t1) / 1000);
	}

	public static void main(String[] args) {
		test(new swarmops.random.MersenneTwister());
		// test(new swarmops.random.JavaRNG());
	}
}
