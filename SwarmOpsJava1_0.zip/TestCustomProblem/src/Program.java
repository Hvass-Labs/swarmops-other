// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

import java.io.IOException;
import swarmops.*;
import swarmops.optimizers.*;

/**
 * Test optimizer on a custom and constrained problem.
 */
public class Program {
	// Create problem object.
	static Problem problem = new CustomProblem();

	// Create optimizer object.
	static Optimizer optimizer = new DE(problem);
//	static Optimizer optimizer = new DESuite(problem, DECrossover.Variant.Rand1Bin, DESuite.DitherVariant.None);

	// Control parameters for optimizer.
	static final double[] parameters = optimizer.getDefaultParameters();
	// static final double[] parameters =
	// PSO.Parameters.AllBenchmarks5Dim10000IterA;

	// Optimization settings.
	static final int numRuns = 50;
	static final int dim = 5;
	static final int dimFactor = 200;
	static final int numIterations = dimFactor * dim;

	// Wrap the optimizer in a logger of result-statistics.
	static final boolean statisticsOnlyFeasible = true;
	static Statistics statistics = new Statistics(optimizer,
			statisticsOnlyFeasible);

	// Wrap it again in a repeater.
	static Repeat repeat = new RepeatSum(statistics, numRuns);

	public static void main(String[] args) throws IOException {
		// Initialize PRNG.
		Globals.random = new swarmops.random.MersenneTwister();

		// Set max number of optimization iterations to perform.
		problem.maxIterations = numIterations;

		// Output optimization settings.
		System.out.printf("Optimizer: %s\n", optimizer.getName());
		System.out.printf("Using following parameters:\n");
		// Tools.PrintParameters(optimizer, parameters);
		System.out.printf("Number of optimization runs: %d\n", numRuns);
		System.out.printf("Problem: %s\n", problem.getName());
		System.out.printf("\tDimensionality: %d\n", dim);
		System.out.printf("\tDim-factor: %d\n", dimFactor);
		System.out.printf("\n");

		// Create a fitness trace for tracing the progress of optimization re.
		// mean.
		int numMeanIntervals = 3000;
		FitnessTrace fitnessTraceMean = new FitnessTraceMean(numIterations,
				numMeanIntervals);

		// Create a fitness trace for tracing the progress of optimization re.
		// quartiles.
		// Note that fitnessTraceMean is chained to this object by passing it to
		// the constructor, this causes both fitness traces to be used.
		int numQuartileIntervals = 10;
		FitnessTrace fitnessTraceQuartiles = new FitnessTraceQuartiles(numRuns,
				numIterations, numQuartileIntervals, fitnessTraceMean);

		// Create a feasibility trace for tracing the progress of optimization
		// re. fesibility.
		FeasibleTrace feasibleTrace = new FeasibleTrace(numIterations,
				numMeanIntervals, fitnessTraceQuartiles);

		// Assign the fitness trace to the optimizer.
		optimizer.fitnessTrace = feasibleTrace;

		// Starting-time.
		long t1 = System.currentTimeMillis();

		// Perform the optimization runs.
		repeat.fitness(parameters);

		// End-time.
		long t2 = System.currentTimeMillis();

		if (statistics.getFeasibleFraction() > 0) {
			// Compute result-statistics.
			statistics.compute();

			// Output best result, as well as result-statistics.
			System.out.printf("Best feasible solution found:\n");
			Tools.printParameters(problem, statistics.bestResult.parameters);
			System.out.printf("\n");
			System.out.printf("Result Statistics:\n");
			System.out.printf("\tFeasible: \t%s of solutions found.\n",
					Tools.formatPercent(statistics.getFeasibleFraction()));
			System.out.printf("\tBest Fitness: \t%s\n",
					Tools.formatNumber(statistics.fitnessStatistics.getMin()));
			System.out.printf("\tWorst: \t\t%s\n",
					Tools.formatNumber(statistics.fitnessStatistics.getMax()));
			System.out.printf("\tMean: \t\t%s\n",
					Tools.formatNumber(statistics.fitnessStatistics.getMean()));
			System.out.printf("\tStd.Dev.: \t%s\n", Tools
					.formatNumber(statistics.fitnessStatistics
							.getStandardDeviation()));
			System.out.printf("\n");
			System.out.printf("Iterations used per run:\n");
			System.out.printf("\tMean: %s\n", Tools
					.formatNumber(statistics.iterationsStatistics.getMean()));
		} else {
			System.out.printf("No feasible solutions found.\n");
		}

		// Output time-usage.
		System.out.printf("\n");
		System.out.printf("Time usage: %.2f seconds\n",
				(double) (t2 - t1) / 1000);

		// Output fitness and feasible traces.
		fitnessTraceMean.writeToFile(optimizer.getName() + "-FitnessTraceMean-"
				+ problem.getName() + ".txt");
		fitnessTraceQuartiles.writeToFile(optimizer.getName()
				+ "-FitnessTraceQuartiles-" + problem.getName() + ".txt");
		feasibleTrace.writeToFile(String.format(optimizer.getName()
				+ "-FeasibleTrace-" + problem.getName() + ".txt"));
	}
}
