SwarmOps - Numeric and heuristic optimization for C#
Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
Please see the file license.txt for license details.
SwarmOps on the internet: http://www.Hvass-Labs.org/


Installation:

To use the SwarmOps JAR-library in Eclipse:

1. Unpack the SwarmOps archive to a convenient directory.
2. Open the workspace in which you will use SwarmOps.
3. Add the SwarmOps JAR-file to the build-path of the
   projects which must use it.
4. Import swarmops.optimizers.* and other classes
   you will need in your source-files.

To use the SwarmOps test-projects in Eclipse:

1. Unpack the SwarmOps archive to a convenient directory.
2. Create a new Eclipse workspace in that directory.
3. Select the menu: File / Import / Existing projects
   and import the SwarmOps projects.


Compiler Compatibility:

SwarmOps was developed in Eclipse build 20100917-0705
using JavaSE 1.6. SwarmOps should be compatible with
all newer versions of Java.


Update History:

Version 1.0:
- First release.
