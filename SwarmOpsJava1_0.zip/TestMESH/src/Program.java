// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

import swarmops.*;
import swarmops.problems.*;
import swarmops.optimizers.*;

/**
 * Compute a mesh of meta-fitness values showing how an optimizer performs when
 * varying its control parameters.
 */
public class Program {
	// Mesh settings.
	static final int meshNumIterationsPerDim = 8;

	// Settings for the optimization layer.
	static final int numRuns = 5;
	static final int dim = 5;
	static final int dimFactor = 2000;
	static final int numIterations = dimFactor * dim;

	// Mangle search-space.
	static final boolean useMangler = false;
	static final double spillover = 0.05; // E.g. 0.05
	static final double displacement = 0.1; // E.g. 0.1
	static final double diffusion = 0.01; // E.g. 0.01
	static final double fitnessNoise = 0.01; // E.g. 0.01

	// Wrap problem-object in search-space mangler.
	static Problem mangle(Problem problem) {
		return (useMangler) ? (new Mangler(problem, diffusion, displacement,
				spillover, fitnessNoise)) : (problem);
	}

	// The optimizer whose control parameters are to be tuned.
	static Optimizer optimizer = new MOL();

	// Fix certain parameters of the optimizer.
	static Double[] parameterMask = { 64.0, null, null };

	// Problems to optimize. That is, the optimizer is having its control
	// parameters tuned to work well on these problems.
	static Problem[] problems = new Problem[] {
			// mangle(new Ackley(dim, numIterations)),
			mangle(new Griewank(dim, numIterations)),
			mangle(new Penalized1(dim, numIterations)),
			// mangle(new Penalized2(dim, numIterations)),
			// mangle(new QuarticNoise(dim, numIterations)),
			// mangle(new Rastrigin(dim, numIterations)),
			mangle(new Rosenbrock(dim, numIterations)),
			mangle(new Schwefel12(dim, numIterations)),
	// mangle(new Schwefel221(dim, numIterations)),
	// mangle(new Schwefel222(dim, numIterations)),
	// mangle(new Sphere(dim, numIterations)),
	// mangle(new Step(dim, numIterations)),
	};

	// The meta-fitness consists of computing optimization performance
	// for the problems listed above over several optimization runs and
	// sum the results, so we wrap the Optimizer-object in a
	// MetaFitness-object which takes of this.
	static MetaFitness metaFitness = new MetaFitness(optimizer, problems,
			numRuns, 0);

	// Print meta-optimization progress.
	static FitnessPrint metaFitnessPrint = new FitnessPrint(metaFitness);

	// Log all candidate solutions.
	static int logCapacity = 20;
	static boolean logOnlyFeasible = false;
	static LogSolutions logSolutions = new LogSolutions(metaFitnessPrint,
			logCapacity, logOnlyFeasible);

	// The meta-optimizer.
	static Optimizer metaOptimizer = new MESH(parameterMask, logSolutions);

	// Control parameters to use for the meta-optimizer.
	static double[] metaParameters = { meshNumIterationsPerDim };

	// Wrap the meta-optimizer in a Statistics object for logging results.
	static final boolean statisticsOnlyFeasible = true;
	static Statistics statistics = new Statistics(metaOptimizer,
			statisticsOnlyFeasible);

	public static void main(String[] args) {
		// Initialize the PRNG.
		Globals.random = new swarmops.random.MersenneTwister();

		// Output settings.
		System.out
				.printf("Mesh of meta-fitness values using benchmark problems.\n");
		System.out.printf("\n");
		System.out.printf("Optimizer to compute mesh for: %s\n",
				optimizer.getName());
		System.out.printf("Mesh, number of iterations per dimension: %d\n",
				meshNumIterationsPerDim);
		System.out
				.printf("Number of benchmark problems: %d\n", problems.length);

		for (int i = 0; i < problems.length; i++) {
			System.out.printf("\t%s\n", problems[i].getName());
		}

		System.out.printf("Dimensionality for each benchmark problem: %d\n",
				dim);
		System.out
				.printf("Number of runs per benchmark problem: %d\n", numRuns);
		System.out.printf("Number of iterations per run: %d\n", numIterations);
		if (useMangler) {
			System.out.printf("Mangle search-space:\n");
			System.out.printf("\tSpillover:     %d\n", spillover);
			System.out.printf("\tDisplacement:  %d\n", displacement);
			System.out.printf("\tDiffusion:     %d\n", diffusion);
			System.out.printf("\tFitnessNoise:  %d\n", fitnessNoise);
		} else {
			System.out.printf("Mangle search-space: No\n");
		}
		System.out.printf("\n");

		System.out
				.printf("0/1 boolean whether optimizer's control parameters are feasible.\n");
		System.out
				.printf("*** Indicates meta-fitness/feasibility is an improvement.\n");
		System.out.printf("\n");
		System.out.printf("Mesh of meta-fitness values:\n");

		// Start-time.
		long t1 = System.currentTimeMillis();

		// Perform the meta-optimization runs.
		statistics.fitness(metaParameters);

		// End-time.
		long t2 = System.currentTimeMillis();

		// Compute result-statistics.
		statistics.compute();

		// Retrieve best-found control parameters for the optimizer.
		double[] bestParameters = statistics.bestResult.parameters;

		// Output results and statistics.
		System.out.printf("\n");
		System.out.printf("Best found parameters for %s optimizer:\n",
				optimizer.getName());
		Tools.printParameters(optimizer, bestParameters);
		System.out.printf("Parameters written in array notation:\n");
		System.out.printf("\t%s\n", Tools.arrayToString(bestParameters));
		System.out.printf("Best parameters have meta-fitness: %s\n",
				Tools.formatNumber(statistics.fitnessStatistics.getMin()));

		// Output best found parameters.
		System.out.printf("\n");
		System.out.printf("Best %d found parameters:\n", logSolutions.capacity);
		for (int i = 0; i < logSolutions.log.size(); i++) {
			Solution candidateSolution = logSolutions.log.get(i);
			System.out.printf("\t%s\t%s\t%d\n",
					Tools.arrayToStringRaw(candidateSolution.parameters),
					Tools.formatNumber(candidateSolution.fitness),
					(candidateSolution.feasible) ? (1) : (0));
		}

		// Output time-usage.
		System.out.printf("\n");
		System.out.printf("Time usage: %.2f seconds\n",
				(double) (t2 - t1) / 1000);
	}
}
